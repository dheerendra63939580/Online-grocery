import React from 'react'
import './Home.css'

const Home = () => {
  return (
    <div className="home-background">
        <span style={{fontSize: "30px",color: "white",backgroundColor:"rgba(0,0,0,.7)",padding:"10px 20px"}}>Explore Our Navbar For Purchasing Products</span>
    </div>
  )
}

export default Home
